'use client'

import { useState } from 'react'
import { Upload, Star, Zap, TrendingUp, Lightbulb, Target } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { useThumbnailAnalysis } from '@/hooks/use-thumbnail-analysis'
import { motion, AnimatePresence } from 'framer-motion'
import { ThumbnailChecklist } from '@/components/thumbnail-checklist'

const MotionButton = motion(Button)

export default function ThumbnailRater() {
  const {
    preview,
    loading,
    result,
    error,
    remainingTries,
    analyzeImage,
    handleFileChange,
  } = useThumbnailAnalysis()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [file, setFile] = useState<File | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (remainingTries <= 0) return
    await analyzeImage(title, description)
  }

  const onFileChange = (file: File | null) => {
    setFile(file)
    handleFileChange(file)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF1E8] to-[#FFF6F0] font-poppins text-[#2C2C2D] py-[100px] px-6 relative overflow-hidden flex items-center justify-center">
      {/* Premium gradient orbs */}
      <motion.div
        className="absolute top-0 left-0 w-[500px] h-[500px] bg-[#FFE144] rounded-full filter blur-[128px] opacity-20"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 90, 0],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
      />
      <motion.div
        className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-[#FFE144] rounded-full filter blur-[128px] opacity-20"
        animate={{
          scale: [1, 1.3, 1],
          rotate: [0, -90, 0],
          x: [0, -50, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "linear"
        }}
      />

      <div className="max-w-4xl w-full mx-auto space-y-8 relative z-10">
        <motion.div
          className="text-center space-y-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-5xl font-bold bg-gradient-to-r from-[#2C2C2D] to-[#454545] inline-block text-transparent bg-clip-text">
            Rate My Thumbnail
          </h1>
          <p className="text-xl text-[#2C2C2D]/80">
            {remainingTries} free {remainingTries === 1 ? 'analysis' : 'analyses'} remaining
          </p>
        </motion.div>

        <motion.form 
          onSubmit={handleSubmit} 
          className="space-y-6 bg-white/80 backdrop-blur-xl p-8 rounded-2xl shadow-2xl border border-white/20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div 
            className={`
              border-2 border-dashed rounded-xl p-8
              ${preview ? 'border-[#FFE144]' : 'border-[#D1D4DA]'}
              transition-all duration-300
              flex flex-col items-center justify-center
              min-h-[300px] relative
              hover:border-[#FFE144] hover:shadow-xl
              group bg-white/50
            `}
          >
            <input
              type="file"
              accept="image/*"
              onChange={(e) => onFileChange(e.target.files?.[0] || null)}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              disabled={loading || remainingTries <= 0}
            />
            
            {preview ? (
              <motion.img
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                src={preview}
                alt="Thumbnail preview"
                className="max-h-[280px] object-contain rounded-lg shadow-xl"
              />
            ) : (
              <div className="text-center">
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400 group-hover:text-[#FFE144] transition-colors" />
                </motion.div>
                <p className="text-lg font-medium">Upload Your Thumbnail</p>
                <p className="text-sm text-gray-500 mb-4">or</p>
                <MotionButton
                  type="button"
                  className="bg-[#FFE144] text-[#2C2C2D] hover:bg-[#FFE144]/90 shadow-lg shadow-[#FFE144]/20"
                  disabled={loading || remainingTries <= 0}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Choose File
                </MotionButton>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <Input
              placeholder="Enter your video title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={loading || remainingTries <= 0}
              className="border-[#D1D4DA] focus:border-[#FFE144] focus:ring-[#FFE144] bg-white/70 backdrop-blur-sm"
            />
            
            <Textarea
              placeholder="Enter your video description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={loading || remainingTries <= 0}
              className="border-[#D1D4DA] focus:border-[#FFE144] focus:ring-[#FFE144] bg-white/70 backdrop-blur-sm"
            />

            <MotionButton
              type="submit"
              className="w-full bg-gradient-to-r from-[#FFE144] to-[#FFD700] text-[#2C2C2D] hover:opacity-90 transition-all shadow-lg shadow-[#FFE144]/20 text-lg py-3"
              disabled={!preview || !title || loading || remainingTries <= 0}
              whileHover={{ scale: 1.02, shadow: "lg" }}
              whileTap={{ scale: 0.98 }}
            >
              {loading ? 'Analyzing...' : 'Analyze Thumbnail'}
            </MotionButton>
          </div>
        </motion.form>

        {loading && (
          <motion.div 
            className="space-y-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Progress value={66} className="h-2" />
            <p className="text-center text-sm">Analyzing your thumbnail...</p>
          </motion.div>
        )}

        {error && (
          <motion.p 
            className="text-red-500 text-center font-medium"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {error}
          </motion.p>
        )}

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { icon: Star, title: "Thumbnail Rating", value: result.thumbnailRating },
                  { icon: Zap, title: "Title Rating", value: result.titleRating },
                  { icon: TrendingUp, title: "Estimated CTR", value: `${result.ctr}%` },
                ].map((item, index) => (
                  <motion.div 
                    key={index}
                    className="text-center p-6 bg-gradient-to-br from-[#2C2C2D] to-[#232324] rounded-xl shadow-2xl border border-white/5"
                    whileHover={{ scale: 1.05, y: -5 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <item.icon className="w-10 h-10 mx-auto mb-3 text-[#FFE144] drop-shadow-lg" />
                    <h3 className="font-semibold mb-2 text-[#FFF1E8]">{item.title}</h3>
                    <p className="text-4xl font-bold text-[#FFE144] drop-shadow-lg">{item.value}</p>
                  </motion.div>
                ))}
              </div>

              <ThumbnailChecklist imageFile={file} />

              <div className="space-y-6">
                <motion.div 
                  className="bg-gradient-to-br from-[#2C2C2D] to-[#232324] rounded-xl p-8 shadow-2xl border border-white/5"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <h3 className="font-semibold mb-6 text-2xl text-[#FFF1E8] tracking-tight">Suggested Titles</h3>
                  <ul className="space-y-4">
                    {result.suggestedTitles.map((title, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-start gap-4 group"
                      >
                        <Lightbulb className="w-6 h-6 mt-1 flex-shrink-0 text-[#FEE044] drop-shadow-lg" />
                        <span className="text-[#FEF1E8] group-hover:text-[#FEE044] transition-colors text-lg">
                          {title}
                        </span>
                      </motion.li>
                    ))}
                  </ul>
                </motion.div>

                <motion.div 
                  className="bg-gradient-to-br from-[#2C2C2D] to-[#232324] rounded-xl p-8 shadow-2xl border border-white/5"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <h3 className="font-semibold mb-6 text-2xl text-[#FFF1E8] tracking-tight">Suggested Improvements</h3>
                  <ul className="space-y-4">
                    {result.improvements.map((improvement, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-start gap-4 group"
                      >
                        <Target className="w-6 h-6 mt-1 flex-shrink-0 text-[#FEE044] drop-shadow-lg" />
                        <span className="text-[#FEF1E8] group-hover:text-[#FEE044] transition-colors text-lg">
                          {improvement}
                        </span>
                      </motion.li>
                    ))}
                  </ul>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {remainingTries <= 0 && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center text-red-500 text-lg font-medium"
          >
            You have used all your free analyses. Please come back later.
          </motion.p>
        )}
      </div>
    </div>
  )
}

