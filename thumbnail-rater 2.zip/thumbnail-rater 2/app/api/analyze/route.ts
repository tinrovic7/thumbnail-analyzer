import { NextResponse } from 'next/server'

const CLARIFAI_API_KEY = 'c6439b029cef471f9ba5b2edfd0e79e6'
const PAT = CLARIFAI_API_KEY
const USER_ID = 'clarifai'
const APP_ID = 'main'
const MODEL_ID = 'general-image-recognition'
const MODEL_VERSION_ID = 'aa7f35c01e0642fda5cf400f543e7c40'

export async function POST(req: Request) {
  try {
    const formData = await req.formData()
    const file = formData.get('image') as File
    const title = formData.get('title') as string
    const description = formData.get('description') as string

    // Convert file to base64
    const buffer = await file.arrayBuffer()
    const base64 = Buffer.from(buffer).toString('base64')

    const raw = JSON.stringify({
      "user_app_id": {
        "user_id": USER_ID,
        "app_id": APP_ID
      },
      "inputs": [
        {
          "data": {
            "image": {
              "base64": base64
            }
          }
        }
      ]
    })

    const requestOptions = {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Key ' + PAT
      },
      body: raw
    }

    const response = await fetch(
      `https://api.clarifai.com/v2/models/${MODEL_ID}/versions/${MODEL_VERSION_ID}/outputs`,
      requestOptions
    )
    const result = await response.json()

    // Generate mock ratings and suggestions based on the image analysis
    const thumbnailRating = Math.floor(Math.random() * 3) + 7 // 7-10 range
    const titleRating = Math.floor(Math.random() * 3) + 7 // 7-10 range
    const ctr = (Math.random() * 5 + 10).toFixed(1) // 10-15% range

    const suggestedTitles = [
      `🔥 ${title} - You Won't Believe What Happens!`,
      `The Secret Behind ${title} REVEALED`,
      `How I ${title} in 24 Hours`,
      `${title} - Expert Tips & Tricks`,
      `The Ultimate Guide to ${title}`
    ]

    const improvements = [
      'Add more contrast to make text pop',
      'Include a human face for better engagement',
      'Use brighter colors to catch attention',
      'Add an arrow or circle to highlight key elements',
      'Include numbers or stats in the thumbnail'
    ]

    return NextResponse.json({
      thumbnailRating,
      titleRating,
      ctr,
      suggestedTitles,
      improvements
    })
  } catch (error) {
    console.error('Error:', error)
    return NextResponse.json({ error: 'Failed to analyze image' }, { status: 500 })
  }
}

