'use client'

import { useState } from 'react'

interface AnalysisResult {
  thumbnailRating: number
  titleRating: number
  ctr: string
  suggestedTitles: string[]
  improvements: string[]
}

export function useThumbnailAnalysis() {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string>('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [error, setError] = useState<string>('')
  const [remainingTries, setRemainingTries] = useState(() => {
    if (typeof window !== 'undefined') {
      return parseInt(sessionStorage.getItem('remainingTries') || '3')
    }
    return 3
  })

  const analyzeImage = async (title: string, description: string) => {
    if (!file) return

    try {
      setLoading(true)
      setError('')

      const formData = new FormData()
      formData.append('image', file)
      formData.append('title', title)
      formData.append('description', description)

      const response = await fetch('/api/analyze', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) throw new Error('Failed to analyze image')

      const data = await response.json()
      setResult(data)
      
      // Update remaining tries
      const newTries = remainingTries - 1
      setRemainingTries(newTries)
      sessionStorage.setItem('remainingTries', newTries.toString())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const handleFileChange = (file: File | null) => {
    setFile(file)
    setResult(null)
    
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    } else {
      setPreview('')
    }
  }

  return {
    file,
    preview,
    loading,
    result,
    error,
    remainingTries,
    analyzeImage,
    handleFileChange,
  }
}

