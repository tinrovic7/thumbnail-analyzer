'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Check } from 'lucide-react'

interface ChecklistItem {
  label: string
  checked: boolean
}

interface ThumbnailChecklistProps {
  imageFile: File | null
}

export function ThumbnailChecklist({ imageFile }: ThumbnailChecklistProps) {
  const [checklist, setChecklist] = useState<ChecklistItem[]>([
    { label: '1280 x 720 pixels', checked: false },
    { label: 'Minimum width: 640 pixels', checked: false },
    { label: 'Recommended ratio: 16:9', checked: false },
    { label: 'Maximum file size: 2MB', checked: false },
    { label: 'Accepted file types: .JPG, .GIF, .BMP, or .PNG', checked: false },
  ])

  const getImageDimensions = (file: File): Promise<{ width: number; height: number }> => {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => {
        resolve({ width: img.width, height: img.height })
      }
      img.src = URL.createObjectURL(file)
    })
  }

  const analyzeImage = async (file: File) => {
    const dimensions = await getImageDimensions(file)
    const fileSize = file.size / (1024 * 1024) // Convert to MB
    const fileType = file.type.split('/')[1].toLowerCase()
    const acceptedTypes = ['jpg', 'jpeg', 'gif', 'bmp', 'png']

    return {
      correctResolution: dimensions.width === 1280 && dimensions.height === 720,
      minWidth: dimensions.width >= 640,
      correctRatio: Math.abs((dimensions.width / dimensions.height) - (16 / 9)) < 0.1,
      validSize: fileSize <= 2,
      validType: acceptedTypes.includes(fileType)
    }
  }

  useEffect(() => {
    if (imageFile) {
      analyzeImage(imageFile).then((results) => {
        setChecklist([
          { label: '1280 x 720 pixels', checked: results.correctResolution },
          { label: 'Minimum width: 640 pixels', checked: results.minWidth },
          { label: 'Recommended ratio: 16:9', checked: results.correctRatio },
          { label: 'Maximum file size: 2MB', checked: results.validSize },
          { label: 'Accepted file types: .JPG, .GIF, .BMP, or .PNG', checked: results.validType },
        ])
      })
    }
  }, [imageFile])

  const completionPercentage = Math.round(
    (checklist.filter(item => item.checked).length / checklist.length) * 100
  )

  return (
    <motion.div 
      className="bg-gradient-to-br from-[#2C2C2D] to-[#232324] rounded-xl p-8 shadow-2xl border border-white/5"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h3 className="font-semibold mb-8 text-2xl text-[#FFF1E8] tracking-tight">
        Youtube Thumbnail Checklist
      </h3>
      
      <div className="grid md:grid-cols-[1fr_auto] gap-10 items-center">
        <ul className="space-y-5">
          {checklist.map((item, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center gap-4 group"
            >
              <motion.div 
                className={`
                  w-7 h-7 rounded-full flex items-center justify-center
                  ${item.checked ? 'bg-[#FEE044]' : 'bg-[#D1D4DA]'}
                  transition-all duration-300 shadow-lg
                  ${item.checked ? 'shadow-[#FEE044]/20' : ''}
                `}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Check className="w-5 h-5 text-[#2C2C2D]" />
              </motion.div>
              <span className="text-[#FFF1E8] text-lg group-hover:text-[#FEE044] transition-colors">
                {item.label}
              </span>
            </motion.li>
          ))}
        </ul>

        <div className="relative w-40 h-40">
          <div className="absolute inset-0 rounded-full bg-[#FEE044]/10 blur-xl"></div>
          <svg className="w-full h-full transform -rotate-90 drop-shadow-2xl">
            <circle
              cx="80"
              cy="80"
              r="70"
              stroke="#D1D4DA"
              strokeWidth="8"
              fill="none"
              className="opacity-10"
            />
            <circle
              cx="80"
              cy="80"
              r="70"
              stroke="#FEE044"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 70}`}
              strokeDashoffset={`${2 * Math.PI * 70 * (1 - completionPercentage / 100)}`}
              className="transition-all duration-1000 ease-out drop-shadow-2xl"
            />
          </svg>
          <motion.div 
            className="absolute inset-0 flex flex-col items-center justify-center text-[#FFF1E8]"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="text-4xl font-bold text-[#FEE044] drop-shadow-lg">
              {completionPercentage}
            </div>
            <div className="text-sm font-medium tracking-wider">% achieved</div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  )
}

